package com.jspiders.companyapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}

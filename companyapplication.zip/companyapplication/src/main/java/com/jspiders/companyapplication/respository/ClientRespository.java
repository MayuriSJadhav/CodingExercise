package com.jspiders.companyapplication.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.companyapplication.entity.Client;


public interface ClientRespository extends JpaRepository<Client, Long> {
}
package com.jspiders.companyapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.companyapplication.entity.User;
import com.jspiders.companyapplication.respository.UserRespository;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000/")
public class UserController {

	@Autowired
    private UserRespository userRespository;

    @GetMapping
    public List<User> getClients() {
        return userRespository.findAll();
    }

    @PostMapping
    public User createClient(@RequestBody User user) {
        return userRespository.save(user);
    }
}

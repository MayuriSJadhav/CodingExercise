package com.jspiders.companyapplication.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.companyapplication.entity.User;

public interface UserRespository extends JpaRepository<User, Long> {

}

package com.jspiders.companyapplication.entity;

import jakarta.persistence.*;
@Entity
public class Client {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;

	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private User user;

	    @ManyToOne
	    @JoinColumn(name = "company_id")
	    private Company company;

	    @Column(unique = true)
	    private String email;

	    @Column
	    private String phone;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}


	   
	}


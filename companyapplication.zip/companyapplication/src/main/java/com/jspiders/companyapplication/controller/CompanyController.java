package com.jspiders.companyapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.companyapplication.entity.Company;
import com.jspiders.companyapplication.respository.CompanyRespository;

@RestController
@RequestMapping("/api/companies")
@CrossOrigin(origins = "http://localhost:3000/")
public class CompanyController {

	@Autowired
    private CompanyRespository companyRespository;

    @GetMapping
    public List<Company> getClients() {
        return companyRespository.findAll();
    }

    @PostMapping
    public Company createClient(@RequestBody Company company) {
        return companyRespository.save(company);
    }
}

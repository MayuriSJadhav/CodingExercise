package com.jspiders.companyapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.jspiders.companyapplication.entity.Client;
import com.jspiders.companyapplication.respository.ClientRespository;

import java.util.List;

@RestController
@RequestMapping("/api/clients")
@CrossOrigin(origins = "http://localhost:3000/")
public class ClientController {
	@Autowired
    private ClientRespository clientRespository;

    @GetMapping
    public List<Client> getClients() {
        return clientRespository.findAll();
    }

    @PostMapping
    public Client createClient(@RequestBody Client client) {
        return clientRespository.save(client);
    }
}



